# `睿Rui` - 代码生成器

**查看文档**

- https://gitee.com/mybatis-mapper/mapper/tree/master/generator
- https://github.com/mybatis-mapper/mapper/tree/master/generator